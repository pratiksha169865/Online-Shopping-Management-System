package com.example.onlineshoppingmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineshoppingmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
